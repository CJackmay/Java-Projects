package cj222xq_Hangman;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class StartGame {
    private HangfileReader gameMechanic;
    private Scanner sc;
    private int dropout;
    private boolean gameSession;
    int count;
    public StartGame(){
        gameMechanic = new HangfileReader();
        sc = new Scanner(System.in);
    }

    public void gameStart() throws IOException {
        gameSessionend(false);
        //Read file
        gameMechanic.readText("animals.txt");
        // Initiate Randomizer
        gameMechanic.call();

        String animal = gameMechanic.getRandomizedAnimal();
        String[] aniletters = new String[animal.length()];
        int wordlength = gameMechanic.size();

        for (int i = 0; i < aniletters.length; i++) {
            aniletters[i] = String.valueOf(animal.charAt(i));
        }

        do {
            boolean formatcheck = false;
            try {
                System.out.print("\nGuess the animal." +
                        "\n\t Here is a hint: Length of word = " + wordlength +
                        "\nInput 1 to Exit or "+
                        "\n Begin (Letter by Letter)===> ");
                String ans = sc.nextLine();
                try {
                    setDropout(ans);
                }
                catch (NumberFormatException e) {
                    for (int k = 0; k < aniletters.length; k++) {
                        if (ans.equalsIgnoreCase(aniletters[k])) {
                            wordlength--;
                            System.out.println("Word has that letter.");
                            for (int j = k; j < aniletters.length - 1; j++) {
                                aniletters[j] = aniletters[j + 1];
                            }
                            formatcheck = true;
                            break;
                        }

                    }
                }
                if(!formatcheck){
                    count++;
                    hangmanImage();
                }

            } catch (InputMismatchException e) {
                e.printStackTrace();
            }

            if(count == 7){
                break;
            }
        } while (wordlength > 0);
        System.out.println("Your word was "+ animal);
        gameSessionend(true);
    }

    public void hangmanImage() {

        if (count == 1) {

            System.out.println("Wrong guess, try again");

            System.out.println();

            System.out.println();

            System.out.println();

            System.out.println();

            System.out.println("___|___");

            System.out.println();

        }

        if (count == 2) {

            System.out.println("Wrong guess, try again");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("___|___");

        }

        if (count == 3) {

            System.out.println("Wrong guess, try again");

            System.out.println("   ____________");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   | ");

            System.out.println("___|___");

        }

        if (count == 4) {

            System.out.println("Wrong guess, try again");

            System.out.println("   ____________");

            System.out.println("   |          _|_");

            System.out.println("   |         /   \\");

            System.out.println("   |        |     |");

            System.out.println("   |         \\_ _/");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("   |");

            System.out.println("___|___");

        }

        if (count == 5) {

            System.out.println("Wrong guess, try again");

            System.out.println("   ____________");

            System.out.println("   |          _|_");

            System.out.println("   |         /   \\");

            System.out.println("   |        |     |");

            System.out.println("   |         \\_ _/");

            System.out.println("   |           |");

            System.out.println("   |           |");

            System.out.println("   |");

            System.out.println("___|___");

        }

        if (count == 6) {

            System.out.println("Wrong guess, try again");

            System.out.println("   ____________");

            System.out.println("   |          _|_");

            System.out.println("   |         /   \\");

            System.out.println("   |        |     |");

            System.out.println("   |         \\_ _/");

            System.out.println("   |           |");

            System.out.println("   |           |");

            System.out.println("   |          / \\ ");

            System.out.println("___|___      /   \\");

        }

        if (count == 7) {

            System.out.println("GAME OVER!");

            System.out.println("   ____________");

            System.out.println("   |          _|_");

            System.out.println("   |         /   \\");

            System.out.println("   |        |     |");

            System.out.println("   |         \\_ _/");

            System.out.println("   |          _|_");

            System.out.println("   |         / | \\");

            System.out.println("   |          / \\ ");

            System.out.println("___|___      /   \\");

        }

    }

    public void setDropout(String anst) throws IOException {

        this.dropout = (int) Double.parseDouble(anst);

        if (dropout == 1){
            System.out.println("Are you sure? (Yes or No)");
            String confirmation = sc.nextLine();
            if(confirmation.equalsIgnoreCase("Yes")) {
                System.exit(0);
            }
            else{
                System.out.println("Back to the game you go!.");
            }

        }
    }
    // TEST METHOD
    public void gameSessionend(Boolean s){
        gameSession = s;
    }

    //TEST METHOD
    public boolean getSession(){
        return gameSession;
    }

    // Test method
    public boolean getsutDropout(String anst) throws IOException {
        boolean check = false;
        try {
            this.dropout = (int) Double.parseDouble(anst);
            if (dropout == 1){
                check = true;
            }
        }
        catch (NumberFormatException nfe){
            System.out.println("Wrong");
        }

        return check;
    }
}