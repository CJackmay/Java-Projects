package cj222xq_Hangman;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Hangman {
    private static volatile int userinput;
    private static Scanner sc = new Scanner(System.in);
    private static GameMechanics run = new GameMechanics();
    private static StartGame play = new StartGame();

    public static void main(String[] args) throws IOException {
        //Produce Start_Menu
        do{
            Menu();

            if (userinput == 2) {
                Instructions();
                System.out.print("\n===>");
                int followup = sc.nextInt();
                if (followup == 1)
                    ;
                else if (followup == 2) {
                    Exit();
                }
            } else if (userinput == 1) {
                play.gameStart();
            }
            else if (userinput !=0 && userinput > 2 || userinput < 0){
                System.out.println("Invalid option");
            }
            else
                Exit();
        }while (userinput != -1);
        System.exit(0);
    }

    public static void Exit(){
        System.out.println("Are you sure? (Yes or No)");
        run.setConfirmaton(sc.next());
        if (run.Exit() == -1)
            run.Menu();
        else if (run.Exit() == 0)
            userinput = -1;
        else
            System.out.println("Input invalid");
    }

    public static void Menu(){
        System.out.print(run.Menu());
        try {
            userinput = sc.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Option invalid");
        }
    }

    public static void Instructions(){
        run.Instructions();
    }

}

