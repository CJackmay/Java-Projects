package cj222xq_Hangman;

public class GameMechanics {
    private String confirmaton;

    public GameMechanics(){
    }

    public String Menu(){
        return("1. Start Game" +
                "\n2. Instructions" +
                "\n0. Exit " +
                "\n===>");
    }

    public void setConfirmaton(String confirmaton) {
        this.confirmaton = confirmaton;
    }

    public String getConfirmaton() {
        return confirmaton;
    }

    public int Exit(){
        if(getConfirmaton().equalsIgnoreCase("Yes")) {
            return 0;
        }
        else if(getConfirmaton().equalsIgnoreCase("No"))
            return -1;

        return 2;
    }

    public void Instructions(){
        System.out.println("****A game of Hangman****" +
                "\n You are expected to guess a word of type Animals in this game." +
                "\n\t There would be a hint. This hint would be the lenght of the word :)" +
                "\n Quick note every failed attempt draws towards hanging a man try to avoid this." +
                "\n\t Your expected to guess letter by letter :)" +
                "\n *****Goodluck you've got 7 trials.*****\n" +
                "1. Back \n" +
                "2. Exit");

    }
}
