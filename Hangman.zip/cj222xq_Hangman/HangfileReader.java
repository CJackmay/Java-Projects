package cj222xq_Hangman;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.lang.String;
import java.util.stream.*;
import java.util.*;

public class HangfileReader implements Hang {
    private List<String> animal;
    private String randomizedAnimal;
    public HangfileReader(){
        animal = new ArrayList<>();
    }

    @Override
    public void call() {
        Random rand = new Random();
        int i = rand.nextInt(animal.size())+1;
        randomizedAnimal = animal.get(i);
        if (randomizedAnimal.length() > 7)
            call();
    }

    @Override
    public void readText(String filename) throws IOException {
        List<String> animals = Files.lines(Paths.get(filename)).collect(Collectors.toList());
		animals.removeIf(s -> s == null || s.equals(" ") || s.length() == 0);

        for (String s : animals) {
            animal.add(s.replaceAll("[\\s\\-()]", ""));
        }
    }

    @Override
    public int size() {
        return randomizedAnimal.length();
    }

    public String getRandomizedAnimal(){return randomizedAnimal;}


}
