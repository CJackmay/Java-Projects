package cj222xq_Hangman;


import java.io.IOException;

/*
An interface to govern major methods expected of the hangman game.
 */
public interface Hang {
    /* Randomizes retrieved words from textfile.*/
    public void call();

    /*Reads file for names of each animal*/
    public void readText(String filename) throws IOException;

    /* Returns hint (length of word)*/
    public int size();

}
